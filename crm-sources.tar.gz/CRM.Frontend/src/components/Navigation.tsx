import { Dropdown, Button } from 'react-bootstrap';
import { FaTachometerAlt, FaUsers, FaChartLine, FaBox, FaBullhorn, FaUser, FaSignOutAlt, FaHome } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Navigation.css';

function NavigationContent() {
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!isAuthenticated) {
    return null; // Don't show nav when not authenticated
  }

  return (
    <div className="sidebar-dock">
      {/* Logo / Brand */}
      <div className="dock-brand">
        <Link to="/" title="CRM Solution">
          <FaHome size={24} />
        </Link>
      </div>

      {/* Navigation Items */}
      <nav className="dock-nav">
        <Link to="/" className="dock-item" title="Dashboard">
          <FaTachometerAlt size={20} />
        </Link>
        <Link to="/customers" className="dock-item" title="Customers">
          <FaUsers size={20} />
        </Link>
        <Link to="/opportunities" className="dock-item" title="Opportunities">
          <FaChartLine size={20} />
        </Link>
        <Link to="/products" className="dock-item" title="Products">
          <FaBox size={20} />
        </Link>
        <Link to="/campaigns" className="dock-item" title="Campaigns">
          <FaBullhorn size={20} />
        </Link>
      </nav>

      {/* Bottom Tools */}
      <div className="dock-bottom">
        {/* User Profile Dropdown */}
        <Dropdown className="dock-item-dropdown">
          <Dropdown.Toggle
            className="dock-item dock-btn dock-profile"
            variant="dark"
            id="user-profile-dropdown"
            title={user?.firstName || 'Profile'}
          >
            <FaUser size={18} />
          </Dropdown.Toggle>

          <Dropdown.Menu className="dropdown-menu-end">
            <Dropdown.Item disabled>
              <strong>{user?.firstName} {user?.lastName}</strong>
            </Dropdown.Item>
            <Dropdown.Item className="small text-muted">{user?.email}</Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item as={Link} to="/2fa">
              <i className="fas fa-lock me-2"></i> Two-Factor Auth
            </Dropdown.Item>
            <Dropdown.Item as={Link} to="/password-reset">
              <i className="fas fa-key me-2"></i> Change Password
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item onClick={handleLogout}>
              <FaSignOutAlt className="me-2" /> Logout
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
    </div>
  );
}

// Navigation wrapper component
function Navigation() {
  const { isAuthenticated } = useAuth();
  
  // Only render NavigationContent if authenticated (hooks will be called inside)
  return isAuthenticated ? <NavigationContent /> : null;
}

export default Navigation;
