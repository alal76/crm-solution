import { useState, useEffect } from 'react';
import { Row, Col, Card } from 'react-bootstrap';
import { opportunityService, campaignService } from '../services/apiService';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

function DashboardPage() {
  const [totalPipeline, setTotalPipeline] = useState(0);
  const [activeCampaigns, setActiveCampaigns] = useState(0);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const pipelineResponse = await opportunityService.getTotalPipeline();
      setTotalPipeline(pipelineResponse.data.totalPipeline);

      const campaignsResponse = await campaignService.getActive();
      setActiveCampaigns(campaignsResponse.data.length);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Dashboard</h2>
        <p className="text-muted">Welcome to CRM Solution</p>
      </div>

      <Row className="mb-4">
        <Col md={6} lg={3} className="mb-3">
          <Card className="stat-card bg-primary text-white">
            <Card.Body>
              <div className="stat-value">${totalPipeline.toFixed(0)}</div>
              <div>Total Pipeline</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6} lg={3} className="mb-3">
          <Card className="stat-card bg-success text-white">
            <Card.Body>
              <div className="stat-value">{activeCampaigns}</div>
              <div>Active Campaigns</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6} lg={3} className="mb-3">
          <Card className="stat-card bg-info text-white">
            <Card.Body>
              <div className="stat-value">0</div>
              <div>New Leads</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6} lg={3} className="mb-3">
          <Card className="stat-card bg-warning text-white">
            <Card.Body>
              <div className="stat-value">0</div>
              <div>Pending Tasks</div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        <Col lg={6} className="mb-4">
          <Card>
            <Card.Header>Sales Pipeline</Card.Header>
            <Card.Body>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={[
                  { month: 'Jan', value: 10000 },
                  { month: 'Feb', value: 12000 },
                  { month: 'Mar', value: 15000 },
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#4e73df" />
                </LineChart>
              </ResponsiveContainer>
            </Card.Body>
          </Card>
        </Col>
        <Col lg={6} className="mb-4">
          <Card>
            <Card.Header>Campaign Performance</Card.Header>
            <Card.Body>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={[
                  { name: 'Email', value: 80 },
                  { name: 'Social', value: 60 },
                  { name: 'Event', value: 40 },
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#4e73df" />
                </BarChart>
              </ResponsiveContainer>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default DashboardPage;
