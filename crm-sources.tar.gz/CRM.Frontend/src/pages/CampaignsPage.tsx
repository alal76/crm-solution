function CampaignsPage() {
  return (
    <div>
      <div className="page-header">
        <h2>Marketing Campaigns</h2>
        <p className="text-muted">Manage your marketing campaigns</p>
      </div>
    </div>
  );
}

export default CampaignsPage;
