function ProductsPage() {
  return (
    <div>
      <div className="page-header">
        <h2>Products</h2>
        <p className="text-muted">Manage your product catalog</p>
      </div>
    </div>
  );
}

export default ProductsPage;
