import React, { useState } from 'react';
import { Container, Card, Button, Form, Alert, Row, Col } from 'react-bootstrap';
import { useAuth } from '../contexts/AuthContext';
import axiosInstance from '../services/apiClient';

function TwoFactorPage() {
  const { user } = useAuth();
  const [step, setStep] = useState<'setup' | 'verify' | 'enabled'>('setup');
  const [setupData, setSetupData] = useState<any>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSetup = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await axiosInstance.post('/auth/2fa/setup');
      setSetupData(response.data);
      setStep('verify');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to setup 2FA');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setLoading(true);
    setError('');

    try {
      await axiosInstance.post('/auth/2fa/verify', {
        code: verificationCode
      });
      setSuccess('Two-factor authentication enabled successfully!');
      setStep('enabled');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to verify code');
    } finally {
      setLoading(false);
    }
  };

  const handleDisable = async () => {
    setLoading(true);
    setError('');

    try {
      await axiosInstance.post('/auth/2fa/disable');
      setSuccess('Two-factor authentication disabled');
      setStep('setup');
      setSetupData(null);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to disable 2FA');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={6}>
          <Card className="shadow">
            <Card.Body className="p-5">
              <h2 className="mb-4">Two-Factor Authentication</h2>

              {error && <Alert variant="danger">{error}</Alert>}
              {success && <Alert variant="success">{success}</Alert>}

              {step === 'setup' && (
                <div>
                  <p className="text-muted mb-4">
                    Enhance your account security by enabling two-factor authentication. You'll need an authenticator app like Google Authenticator or Microsoft Authenticator.
                  </p>
                  <Button
                    variant="primary"
                    onClick={handleSetup}
                    disabled={loading}
                    className="w-100"
                  >
                    {loading ? 'Setting up...' : 'Setup Two-Factor Authentication'}
                  </Button>
                </div>
              )}

              {step === 'verify' && setupData && (
                <div>
                  <div className="mb-4">
                    <h5>Step 1: Scan QR Code</h5>
                    <p className="text-muted">
                      Scan this QR code with your authenticator app:
                    </p>
                    <div className="text-center mb-3">
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
                          setupData.qrCodeUrl
                        )}`}
                        alt="2FA QR Code"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <h5>Step 2: Save Backup Codes</h5>
                    <p className="text-muted">Save these backup codes in a safe place:</p>
                    <div className="alert alert-info">
                      {setupData.backupCodes?.map((code: string, idx: number) => (
                        <div key={idx}>{code}</div>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h5>Step 3: Verify Code</h5>
                    <Form.Group>
                      <Form.Label>Enter the 6-digit code from your authenticator app:</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="000000"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        maxLength={6}
                      />
                    </Form.Group>
                  </div>

                  <Button
                    variant="success"
                    onClick={handleVerify}
                    disabled={loading || verificationCode.length !== 6}
                    className="w-100"
                  >
                    {loading ? 'Verifying...' : 'Verify and Enable 2FA'}
                  </Button>
                </div>
              )}

              {step === 'enabled' && (
                <div>
                  <Alert variant="success">
                    <i className="fas fa-check-circle me-2"></i>
                    Two-factor authentication is now enabled on your account.
                  </Alert>
                  <Button
                    variant="danger"
                    onClick={handleDisable}
                    disabled={loading}
                    className="w-100"
                  >
                    {loading ? 'Disabling...' : 'Disable 2FA'}
                  </Button>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default TwoFactorPage;
