import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Card, Alert, Row, Col } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import '../styles/Auth.css';

function RegisterPage() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [oauthEnabled, setOauthEnabled] = useState(false);
  const { register, googleLogin, initiateMicrosoftLogin } = useAuth();
  const navigate = useNavigate();

  const googleClientId = process.env.REACT_APP_GOOGLE_CLIENT_ID;
  const microsoftClientId = process.env.REACT_APP_MICROSOFT_CLIENT_ID;
  const microsoftTenantId = process.env.REACT_APP_MICROSOFT_TENANT_ID;

  useEffect(() => {
    // Check if OAuth credentials are configured
    const hasOAuthConfig = googleClientId && microsoftClientId && microsoftTenantId;
    setOauthEnabled(!!hasOAuthConfig);

    // Only load Google Sign-In script if credentials are available
    if (!googleClientId) {
      console.warn('Google OAuth: REACT_APP_GOOGLE_CLIENT_ID not configured');
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);

    script.onload = () => {
      if (window.google) {
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: handleGoogleResponse
        });
        const googleButton = document.getElementById('google-signup-button');
        if (googleButton) {
          window.google.accounts.id.renderButton(
            googleButton,
            { theme: 'outline', size: 'large', width: '100%' }
          );
        }
      }
    };

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, [googleClientId]);

  const handleGoogleResponse = async (response: any) => {
    if (response.credential) {
      setError('');
      setLoading(true);
      try {
        await googleLogin(response.credential);
        navigate('/dashboard');
      } catch (err: any) {
        setError(err.response?.data?.message || 'Google sign up failed');
        setLoading(false);
      }
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);

    try {
      await register(formData);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleMicrosoftSignUp = () => {
    setError('');
    setLoading(true);
    try {
      initiateMicrosoftLogin();
    } catch (err: any) {
      setError(err.message || 'Microsoft sign up failed');
      setLoading(false);
    }
  };

  return (
    <Container className="auth-container">
      <Row className="justify-content-center">
        <Col md={6} lg={5}>
          <Card className="auth-card shadow">
            <Card.Body className="p-5">
              <h2 className="text-center mb-4">Create Account</h2>

              {error && <Alert variant="danger">{error}</Alert>}

              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Username</Form.Label>
                  <Form.Control
                    type="text"
                    name="username"
                    placeholder="Choose a username"
                    value={formData.username}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Email Address</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>First Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="firstName"
                        placeholder="First name"
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="lastName"
                        placeholder="Last name"
                        value={formData.lastName}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    placeholder="Enter a strong password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-4">
                  <Form.Label>Confirm Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="confirmPassword"
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 mb-3"
                  disabled={loading}
                >
                  {loading ? 'Creating Account...' : 'Sign Up'}
                </Button>
              </Form>

              {oauthEnabled ? (
                <>
                  <div className="divider">
                    <span>or sign up with</span>
                  </div>

                  <div className="oauth-buttons">
                    <div id="google-signup-button" style={{ width: '100%' }}></div>
                    <Button
                      variant="outline-secondary"
                      className="oauth-btn"
                      onClick={handleMicrosoftSignUp}
                      disabled={loading}
                    >
                      <i className="fab fa-microsoft me-2"></i> Microsoft
                    </Button>
                  </div>
                </>
              ) : (
                <Alert variant="info" className="mt-3">
                  <small>OAuth sign up is not configured. Please contact administrator.</small>
                </Alert>
              )}

              <p className="text-center mt-4">
                Already have an account?{' '}
                <Link to="/login" className="text-decoration-none">
                  Login here
                </Link>
              </p>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default RegisterPage;
