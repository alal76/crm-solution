import React, { useState, useEffect } from 'react';
import { Form, Button, Card, Alert } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import '../styles/Auth.css';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [oauthEnabled, setOauthEnabled] = useState(false);
  const { login, googleLogin, initiateMicrosoftLogin } = useAuth();
  const navigate = useNavigate();

  const googleClientId = process.env.REACT_APP_GOOGLE_CLIENT_ID;
  const microsoftClientId = process.env.REACT_APP_MICROSOFT_CLIENT_ID;
  const microsoftTenantId = process.env.REACT_APP_MICROSOFT_TENANT_ID;

  useEffect(() => {
    // Check if OAuth credentials are configured
    const hasOAuthConfig = googleClientId && microsoftClientId && microsoftTenantId;
    setOauthEnabled(!!hasOAuthConfig);

    // Only load Google Sign-In script if credentials are available
    if (!googleClientId) {
      console.warn('Google OAuth: REACT_APP_GOOGLE_CLIENT_ID not configured');
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);

    script.onload = () => {
      if (window.google) {
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: handleGoogleResponse
        });
        const googleButton = document.getElementById('google-login-button');
        if (googleButton) {
          window.google.accounts.id.renderButton(
            googleButton,
            { theme: 'outline', size: 'large', width: '100%' }
          );
        }
      }
    };

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, [googleClientId]);

  const handleGoogleResponse = async (response: any) => {
    if (response.credential) {
      setError('');
      setLoading(true);
      try {
        await googleLogin(response.credential);
        navigate('/dashboard');
      } catch (err: any) {
        setError(err.response?.data?.message || 'Google login failed');
        setLoading(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleMicrosoftLogin = () => {
    setError('');
    setLoading(true);
    try {
      initiateMicrosoftLogin();
    } catch (err: any) {
      setError(err.message || 'Microsoft login failed');
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <Card className="auth-card shadow-lg">
        <h2 className="text-center">Login to CRM</h2>
        <Card.Body>
          {error && <Alert variant="danger">{error}</Alert>}

          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-4">
              <Form.Label>Email Address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <Form.Label>Password</Form.Label>
                <Link to="/password-reset" className="small">
                  Forgot password?
                </Link>
              </div>
              <Form.Control
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </Form.Group>

            <Button
              variant="primary"
              type="submit"
              className="w-100"
              disabled={loading}
            >
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </Form>

          {oauthEnabled ? (
            <>
              <div className="divider">
                <span>or continue with</span>
              </div>

              <div className="oauth-buttons">
                <div id="google-login-button" style={{ width: '100%' }}></div>
                <Button
                  variant="outline-secondary"
                  className="oauth-btn"
                  onClick={handleMicrosoftLogin}
                  disabled={loading}
                >
                  <i className="fab fa-microsoft me-2"></i> Microsoft
                </Button>
              </div>
            </>
          ) : (
            <Alert variant="info" className="mt-3">
              <small>OAuth login is not configured. Please contact administrator.</small>
            </Alert>
          )}

          <p className="text-center">
            Don't have an account?{' '}
            <Link to="/register" className="text-decoration-none">
              Sign up here
            </Link>
          </p>
        </Card.Body>
      </Card>
    </div>
  );
}

export default LoginPage;
