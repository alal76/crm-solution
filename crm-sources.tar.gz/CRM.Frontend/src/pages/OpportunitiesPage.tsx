function OpportunitiesPage() {
  return (
    <div>
      <div className="page-header">
        <h2>Opportunities</h2>
        <p className="text-muted">Manage your sales opportunities</p>
      </div>
    </div>
  );
}

export default OpportunitiesPage;
