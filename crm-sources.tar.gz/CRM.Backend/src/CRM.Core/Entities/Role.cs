// This file is deprecated - UserRole enum has been moved to User.cs
